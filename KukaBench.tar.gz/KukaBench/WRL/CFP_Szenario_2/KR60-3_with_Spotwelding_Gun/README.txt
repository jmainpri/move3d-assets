
"KR60-3_Link6.wrl" is substituted by "KR60-3_Link6_with_Spotwelding_Gun.wrl"

so that the spotwelding gun is included in the geometry of the last link of the robot.

All the params (DH, translation and rotation of the links) stay the same as in scenario 1!

Hence, the spotwelding gun which normally has one or two additional degrees of freedom is not articulated in this model.